package com.anudip.daoimpl;
import java.util.Scanner;
import org.hibernate.Session;
import org.hibernate.Transaction;
import com.anudip.an.config.HibernateUtil;
import com.anudip.an.dao.PerformanceDao;
import com.anudip.an.entity.Performance;
public class PerformanceDaoImpl implements PerformanceDao  {
	Session session =HibernateUtil.getSessionFactory().openSession();
	Transaction t=session.beginTransaction();
	Scanner sc=new Scanner(System.in);
	@SuppressWarnings("deprecation")
	public void addPerformance() {
		int n;
		String a,s,d,e;
		System.out.println("Enter S_Attendance");
		n=sc.nextInt();
		System.out.println("Enter S_Status");
		a=sc.next();
		System.out.println("Enter S_Testgrade");
		s=sc.next();
		System.out.println("Enter S_Labgrade");
		d=sc.next();
		System.out.println("Enter S_Overallperformance");
		e=sc.next();
		System.out.println("Enter Student_id");
		n=sc.nextInt();
		
		Performance per=new Performance();
		per.setS_Attendance(n);
		per.setS_Status(a);
		per.setS_Testgrade(s);
		per.setS_LabGrade(d);
		per.setS_Overallperformance(e);
		
		session.save(per);
		t.commit();
		System.out.println("inserted successfully");
}
	public void fetchPerformance() {
		System.out.println("Enter S_Attendance");
		int n=sc.nextInt();
		Performance per=session.get(Performance.class,n);
		System.out.println(per.getS_Attendance()+" "+per.getS_Status()+" "+per.getS_Testgrade()+" "+per.getS_LabGrade()+" "+per.getS_Overallperformance());
}
	@SuppressWarnings({ "deprecation", "unused" })   
	public void updatePerformance() {
		System.out.println("Enter S_Status ");
		String a=sc.next();
		Performance per=session.get(Performance.class,a);
		System.out.println("Enter S_Testgrade");
		String s=sc.next();
		System.out.println("Enter S_Overallperformance");
		String e=sc.next();
		per.setS_Testgrade(e);;
		per.setS_Overallperformance(a);
		session.update(per);;
		t.commit();
		System.out.println("Updated Successfully");
	}
	@SuppressWarnings("deprecation")
	public void deletePerformance() {
		System.out.println("Enter S_Labgrade");
		int n=sc.nextInt();
		Performance per=session.get(Performance.class,n);
		session.delete(per);
		t.commit();
		System.out.println("deleted Successfully");
			
		}
	
}	   
			  

