package com.anudip.daoimpl;
import java.util.Scanner;
import org.hibernate.Session;
import org.hibernate.Transaction;
import com.anudip.an.config.HibernateUtil;
import com.anudip.an.dao.StudentDao;
import com.anudip.an.entity.Course;
import com.anudip.an.entity.Student;
    public  class StudentDaoImpl implements StudentDao{
    Session session =HibernateUtil.getSessionFactory().openSession();
    Transaction t=session.beginTransaction();
    Scanner sc=new Scanner(System.in);
   
	   @SuppressWarnings("deprecation")
	public void addStudent() {
		int n,m;
		String a,s,b;
		long d;
		System.out.println("Enter Student_id");
		n=sc.nextInt();
		System.out.println("Enter Name");
		a=sc.next();
		System.out.println("Enter DOB");
		s=sc.next();
		System.out.println("Enter Gender");
		b=sc.next();
		System.out.println("Enter phoneno");
		d=sc.nextLong();
		System.out.println("Enter CourseId");
		m=sc.nextInt();
		
		Student stu=new Student();
		Course cou = new Course();
		stu.setStudent_Id(n);
		stu.setStudent_Name(a);
		stu.setStudent_Dob(s);
		stu.setStudent_Gender(b);
		stu.setStudent_Phoneno(d);
		cou.setCourseId(m);
		session.save(stu);
		t.commit();
		System.out.println("inserted successfully");
		
	}
      
    public void fetchStudent() {
		System.out.println("Enter id");
		int n=sc.nextInt();
		Student stu=session.get(Student.class,n);
		System.out.println(stu.getStudent_Id()+" "+stu.getStudent_Name()+" "+stu.getStudent_Dob()+" "+stu.getStudent_Gender()+" "+stu.getStudent_Phoneno());
		
	}


	public void updateStudent() {
		System.out.println("Enter Id");
		int n=sc.nextInt();
		Student stu=session.get(Student.class,n);
		System.out.println("Enter changed phoneno");
		long d=sc.nextLong();
		stu.setStudent_Phoneno(d);
		session.update(stu);
		t.commit();
		System.out.println("Updated Successfully");
	}

	
	
	@SuppressWarnings("deprecation")
	public void deleteStudent() {
		System.out.println("Enter id");
		int n=sc.nextInt();
		Student stu=session.get(Student.class,n);
		session.delete(stu);
		t.commit();
		System.out.println("deleted Successfully");
			
		}
	
		
	}
	   

    

