package com.anudip.daoimpl;

import java.util.Scanner;
import org.hibernate.Session;
import org.hibernate.Transaction;
import com.anudip.an.config.HibernateUtil;
import com.anudip.an.dao.CourseDao;
import com.anudip.an.entity.Course;
	public  class CourseDaoImpl implements CourseDao{
	    Session session =HibernateUtil.getSessionFactory().openSession();
	    Transaction t=session.beginTransaction();
	    Scanner sc=new Scanner(System.in);
	    
	    @SuppressWarnings("deprecation")
		   public void addCourse() {
			int n;
			String a,s,d,b;
			
			
			System.out.println("Enter Course_id");
			n=sc.nextInt();
			System.out.println("Enter CourseName");
			a=sc.next();
			System.out.println("Enter CourseDescription");
			s=sc.next();
			System.out.println("Enter Duration");
			b=sc.next();
			System.out.println("Enter Location");
			d=sc.next();
			
			Course cou=new Course();
			cou.setCourseId(n);
			cou.setCourseName(a);
			cou.setCourseDesc(s);
			cou.setDuration(b);
			cou.setLocation(d);
			
			session.save(cou);
			t.commit();
			System.out.println("inserted successfully");
			
		}
	     
	    public void fetchCourse() {
			System.out.println("Enter id");
			int n=sc.nextInt();
			Course cou=session.get(Course.class,n);
			System.out.println(cou.getCourseId()+" "+cou.getCourseName()+" "+cou.getCourseDesc()+" "+cou.getDuration()+" "+cou.getLocation());
			
			
		}

		@SuppressWarnings("deprecation")
		public void updateCourse() {
			System.out.println("Enter Id");
			int n=sc.nextInt();
			Course cou=session.get(Course.class,n);
			System.out.println("Enter Location");
			String d=sc.next();
			System.out.println("Enter coursename");
			String a=sc.next();
			cou.setLocation(d);
			cou.setCourseName(a);
			session.update(cou);
			t.commit();
			System.out.println("Updated Successfully");
		}

		@SuppressWarnings("deprecation")
		public void deleteCourse() {
			System.out.println("Enter Course_id");
			int n=sc.nextInt();
			Course cou=session.get(Course.class,n);
			session.delete(cou);
			t.commit();
			System.out.println("deleted Successfully");
				
			}
		

		
		
			
		}
		   

	    


