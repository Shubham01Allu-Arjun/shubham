package com.anudip.an;

import java.util.Scanner;

import com.anudip.daoimpl.CourseDaoImpl;
import com.anudip.daoimpl.PerformanceDaoImpl;
import com.anudip.daoimpl.StudentDaoImpl;

@SuppressWarnings("unused")
public class MainApp  {
	
	public static void main( String[] args ) {
	  
	

	StudentDaoImpl cdao=new StudentDaoImpl() ;
	   // CourseDaoImpl cdao1=new CourseDaoImpl();
		
	    
		@SuppressWarnings("resource")
		Scanner sc = new Scanner(System.in);
	    int option;
	    System.out.println("Welcome to Namrata Foundation");
	    System.out.println("--------------");
	    System.out.println(" 1.Student \n 2. Performance ");
	    System.out.println("Enter Option");
	    System.out.println("------------------------------");
	    option=sc.nextInt();
	    switch (option) {
		case 1: {
			 
			StudentDaoImpl cdao1=new StudentDaoImpl() ;
			char a;
			do {
				System.out.println("Student Management Application");
				System.out.println("------------------");
				System.out.println(" 1.Add Student \n 2.Read Student \n 3.Update Student \n 4.Delete Student \n 5.Exit ");
				System.out.println("------------------");
				System.out.println("Enter the Details student");

				int ch = sc.nextInt();
				switch (ch) {
				case 1: {
					cdao1.addStudent();
					break;
					}
				case 2: {
					cdao1.fetchStudent();
					break;
				    }
				case 3: {

					break;
				    }
				case 4: {
				
					cdao1.deleteStudent();
				    break;
				}
				case 5: {
					System.exit(0);
					break;
				}
				default:
					System.out.println("invalid choice");
				}
				
				System.out.println("Do you continue ? Y/N");
				 a = sc.next().charAt(0);
			}
			while(a == 'Y' || a == 'y');
			System.out.println("Thanks .........");

			}
		break;
		
		/*case 2: {
			CourseDaoImpl cdao1=new CourseDaoImpl();
			char a;
			do {
				System.out.println("Course Management Application");
				System.out.println("------------------");
				System.out.println(" 1.add \n 2.read \n 3.update \n 4.delete \n 5.exit ");
				System.out.println("------------------");
				System.out.println("Enter Details");

				int ch = sc.nextInt();
				switch (ch) {
				case 1: {

					cdao1.addCourse();
					break;
					
				}
				case 2: {
					cdao1.fetchCourse();
					break;
				}
				case 3: {
					cdao1.updateCourse();
				break;
				}
				case 4: {
					cdao1.deleteCourse();

					break;
				}
				case 5: {
					System.exit(0);
					break;
				}
				default:
					System.out.println("invalid choice");
				}
				
				System.out.println("Do you continue ? Y/N");
				 a = sc.next().charAt(0);
			}
			while(a == 'Y' || a == 'y');
			System.out.println("Thanks .........");

			}
			break;*/
		case 2: {
			PerformanceDaoImpl cdao2=new PerformanceDaoImpl();
			char a;
			do {
				//System.out.println("Performance Management Application");
				System.out.println("------------------");
				System.out.println(" 1.Add performance \n 2.Read Performance \n 3.Update Performance \n 4.Delete Performance \n 5.Exit ");
				System.out.println("------------------");
				System.out.println("Enter the Details performance");

				int ch = sc.nextInt();
				switch (ch) {
				case 1: {

					cdao2.addPerformance();
					
					
					break;
					
				}
				case 2: {
					cdao2.fetchPerformance();
					break;
				}
				case 3: {
					cdao2.updatePerformance();
				break;
				}
				case 4: {
					cdao2.deletePerformance();
					break;
				}
				case 5: {
					System.exit(0);
					break;
				}
				default:
					System.out.println("invalid choice");
				}
				
				System.out.println("Do you continue ? Y/N");
				 a = sc.next().charAt(0);
			}
			while(a == 'Y' || a == 'y');
			System.out.println("Thanks .........");

			}
			break;
		}
		}
		
	
}


	
