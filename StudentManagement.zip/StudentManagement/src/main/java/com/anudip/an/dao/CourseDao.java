package com.anudip.an.dao;

public interface CourseDao {

	 public void addCourse();
	   
	   //fetch Exsiting employee details
	   
	   public void fetchCourse();
	   
	   //Changing existing employee details
	   
	   public void updateCourse();
	   
	   //remove existing employee details
	   
	   public void deleteCourse();
	}





