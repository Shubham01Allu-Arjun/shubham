package com.anudip.an.dao;

public interface StudentDao {
	
		//employee dao jaha pe sare abstract method aayenge like
			//save new employee details
				
			   public void addStudent();
			   
			   
			   
			   public void fetchStudent();
			   
			   //Changing existing employee details
			   
			   public void updateStudent();
			   
			   //remove existing employee details
			   
			   public void deleteStudent();
			}








