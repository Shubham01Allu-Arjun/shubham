package com.anudip.an.entity;

import java.util.List;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;


@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "Course")
public class Course {
	
	
	@Id
	@Column(name = "CourseId")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer courseId;
	@Column(name = "CourseName")
	private String courseName;
	@Column(name = "CourseDescription",length=30)
	private String courseDesc;
	@Column(name = "Duartion")
	private String duration;
	@Column(name = "Location")
	private String location;
	
	@OneToMany(mappedBy = "course")
	private List<Student> student;
	

		
}
