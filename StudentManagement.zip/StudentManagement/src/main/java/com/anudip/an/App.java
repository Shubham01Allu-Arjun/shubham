package com.anudip.an;

import java.util.Scanner;
import com.anudip.daoimpl.CourseDaoImpl;
import com.anudip.daoimpl.StudentDaoImpl;


public class App {

	@SuppressWarnings("resource")
	public static void main( String[] args ) {
    StudentDaoImpl cdao=new StudentDaoImpl();
    CourseDaoImpl cdao1=new CourseDaoImpl();
    Scanner sc = new Scanner(System.in);
	char a;
	do {
		System.out.println("Course Management Application");
		System.out.println("------------------");
		System.out.println(" 1.add \n 2.read \n 3.update \n 4.delete \n 5.exit ");
		System.out.println("------------------");
		System.out.println("Enter Details");

		int ch = sc.nextInt();
		switch (ch) {
		case 1: {

			cdao1.addCourse();
			cdao.addStudent();
			
			break;
			
		}
		case 2: {
			cdao1.fetchCourse();
			cdao.fetchStudent();
			break;
		}
		case 3: {
			cdao1.updateCourse();
			cdao.updateStudent();
			break;
		}
		case 4: {
			cdao1.deleteCourse();
			cdao.deleteStudent();
			break;
		}
		case 5: {
			System.exit(0);
			break;
		}
		default:
			System.out.println("invalid choice");
		}
		
		System.out.println("Do you continue ? Y/N");
		 a = sc.next().charAt(0);
	}
	while(a == 'Y' || a == 'y');
	System.out.println("Thanks .........");

	}
}



