//package com.anudip.an.dto;
//
//import jakarta.persistence.Column;
//import jakarta.persistence.GeneratedValue;
//import jakarta.persistence.GenerationType;
//import jakarta.persistence.Id;
//import jakarta.validation.constraints.NotNull;
//import lombok.Getter;
//import lombok.Setter;
//@Getter
//@Setter
//public class StudentDto {
//	@Id // primary key
//	@GeneratedValue(strategy = GenerationType.AUTO)
//	//auto increment
//	@NotNull(message="enter your Student_id")
//	 private int student_id;
//	@Column(length = 20, nullable = false)
//	@NotNull(message="enter your Name")
//	private String Name;
//			
//	@Column(length = 10, nullable = false)
//	@NotNull(message="enter your DOB")
//	private double DOB;
//			
//	@Column(length = 10, nullable = false)
//	@NotNull(message="enter your Gender")
//	private String Gender;
//	
//	@Column(length = 10, nullable = false)
//	@NotNull(message="enter your phoneno")
//	private long phoneno;
//}
//

