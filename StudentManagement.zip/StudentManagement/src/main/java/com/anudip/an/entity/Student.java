package com.anudip.an.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "Student")
public class Student {
	
	@Id	
	  private int Student_Id;
	  @Column(name = "Student_Name",length=20)
	  private String Student_Name;
	  @Column(name = "Student_Dob")
	  private String Student_Dob;
	  @Column(name = "Student_Gender")
	  private String Student_Gender;
	  @Column(name = "Student_phoneno")
	  private long Student_Phoneno;
	  
	  @ManyToOne
	  @JoinColumn(name="CourseId")
	  private Course course;
	  


}
	  
	 

