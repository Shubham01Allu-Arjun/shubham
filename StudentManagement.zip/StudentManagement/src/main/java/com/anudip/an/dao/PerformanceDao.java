package com.anudip.an.dao;

public interface PerformanceDao {
	 public void addPerformance();
	   
	   //fetch Exsiting employee details
	   
	   public void fetchPerformance();
	   
	   //Changing existing employee details
	   
	   public void updatePerformance();
	   
	   //remove existing employee details
	   
	   public void deletePerformance();

}
