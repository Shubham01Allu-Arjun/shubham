package com.anudip.an.entity;



import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity

@Table(name="Performance")
public class Performance {
	@Id
	@Column(name="S_Attendance")
	private int S_Attendance;
	@Column(name="S_Status")
	private String S_Status;
	@Column(name="S_Testgrade")
	private String S_Testgrade;
	@Column(name="S_Labgrade")
	private String S_LabGrade;
	@Column(name="S_Overallperformance")
	private String S_Overallperformance;
	
	@OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "Student_Id")
    private Performance performance;
	

}
